package com.yourgroup.airbattle.core;

public enum GameState {
    START_MENU,
    RUNNING,
    PAUSED,
    GAME_OVER
}
